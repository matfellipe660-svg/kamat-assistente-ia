# KAMAT Assistente IA — site para celular

Protótipo de chat em português que tenta consultar páginas HTML acessíveis de `kamat.de`, responde com base nos trechos recuperados e apresenta links de referência. **Não controla a máquina** e não substitui o manual específico, treinamento ou procedimentos de segurança.

## Publicar online pelo navegador (recomendado fazer a primeira configuração no PC)

### 1. Crie uma conta no GitHub
Acesse https://github.com/ e crie uma conta, se ainda não tiver.

### 2. Crie um repositório
- Clique em **New repository**.
- Nome sugerido: `kamat-assistente-ia`.
- Para começar, selecione **Private** se não quiser que o código fique público.
- Crie o repositório.

### 3. Envie os arquivos do projeto
Extraia o ZIP e envie para o repositório estes arquivos:
- `app.py`
- `requirements.txt`
- `README.md`

Não envie um arquivo `.env` que contenha chave de API. O `.env.example` é apenas um modelo e não contém uma chave real.

### 4. Publique no Streamlit Community Cloud
- Acesse https://share.streamlit.io/ e entre com sua conta GitHub.
- Clique em **Create app**.
- Selecione o repositório `kamat-assistente-ia`, a branch `main` e o arquivo `app.py`.
- Em **Advanced settings / Secrets**, adicione:

  ```toml
  OPENAI_API_KEY = "cole_sua_chave_de_API_aqui"
  OPENAI_MODEL = "gpt-4.1-mini"
  ```

- Clique em **Deploy** e espere o aplicativo iniciar.
- A plataforma fornecerá um endereço terminado em `.streamlit.app`. Abra esse endereço no celular.

Documentação oficial: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy

## Chave da API
Crie e gerencie sua chave em https://platform.openai.com/api-keys. A API é cobrada separadamente da assinatura ChatGPT. Nunca compartilhe a chave nem a coloque em arquivos públicos do GitHub. No Streamlit, configure-a em **Secrets**, não no código. Informações: https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety

## Limitações e segurança
- A coleta tenta indexar até 70 páginas HTML do domínio `kamat.de`, começando por páginas conhecidas e um sitemap se disponível. Isso não garante que todas as páginas ou PDFs do site sejam consultados.
- A busca usa palavras-chave e pode não encontrar um documento relevante. O site pode mudar, limitar acessos ou exigir login.
- A restrição de domínio é aplicada no código de coleta; não é uma garantia absoluta contra erros do modelo. A resposta usa apenas trechos recuperados, mas deve ser validada antes de qualquer uso técnico.
- Não use para decidir parâmetros críticos, contornar alarmes, desativar proteções ou realizar manutenção perigosa. Siga o manual exato, os procedimentos da fábrica e o responsável técnico.
- Antes de uso na fábrica, peça à TI/engenharia para revisar o aplicativo, a política de dados e a segurança.
