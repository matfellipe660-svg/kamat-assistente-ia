import os
import re
import time
from urllib.parse import urlparse, urljoin
import requests
import streamlit as st
from bs4 import BeautifulSoup
from dotenv import load_dotenv

load_dotenv()

APP_TITLE = "KAMAT Assistente IA"
ALLOWED_HOSTS = {"kamat.de", "www.kamat.de"}
SEEDS = [
    "https://www.kamat.de/",
    "https://www.kamat.de/en/",
    "https://www.kamat.de/en/information-centre/",
    "https://www.kamat.de/infocenter/",
    "https://www.kamat.de/infocenter/downloads/",
    "https://www.kamat.de/en/sitemap/",
]
HEADERS = {"User-Agent": "KAMAT-Assistente-IA/1.0 (operator documentation assistant)"}
MAX_PAGES = 70
MAX_TEXT_CHARS = 12000

st.set_page_config(page_title=APP_TITLE, page_icon="🏭", layout="wide")

def allowed_url(url):
    try:
        p = urlparse(url)
        return p.scheme in ("http", "https") and p.hostname and p.hostname.lower() in ALLOWED_HOSTS
    except Exception:
        return False

def clean_text(html):
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "noscript", "svg"]):
        tag.decompose()
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    main = soup.find("main") or soup.find("article") or soup.body or soup
    text = re.sub(r"\s+", " ", main.get_text(" ", strip=True)).strip()
    return title, text, soup

@st.cache_data(ttl=1800, show_spinner=False)
def crawl_kamat():
    """Fetch a bounded set of pages from kamat.de only."""
    session = requests.Session()
    session.headers.update(HEADERS)
    queue = list(SEEDS)
    seen = set()
    pages = []
    # Try the official sitemap, but only follow URLs on the approved domain.
    for sitemap in ("https://www.kamat.de/sitemap.xml", "https://www.kamat.de/en/sitemap/"):
        try:
            r = session.get(sitemap, timeout=10)
            if r.ok and "xml" in r.headers.get("content-type", "").lower():
                xml = BeautifulSoup(r.text, "xml")
                for loc in xml.find_all("loc"):
                    u = loc.get_text(strip=True)
                    if allowed_url(u):
                        queue.append(u)
        except requests.RequestException:
            pass

    while queue and len(pages) < MAX_PAGES:
        url = queue.pop(0)
        if not allowed_url(url):
            continue
        # Normalize fragments and avoid repeated URLs.
        url = url.split("#", 1)[0]
        if url in seen:
            continue
        seen.add(url)
        try:
            response = session.get(url, timeout=12, allow_redirects=True)
            if not response.ok or not allowed_url(response.url):
                continue
            ctype = response.headers.get("content-type", "").lower()
            if "text/html" not in ctype:
                continue
            title, text, soup = clean_text(response.text)
            if len(text) > 80:
                pages.append({"url": response.url, "title": title or response.url, "text": text[:MAX_TEXT_CHARS]})
            for a in soup.find_all("a", href=True):
                target = urljoin(response.url, a["href"]).split("#", 1)[0]
                if allowed_url(target) and target not in seen and target not in queue:
                    queue.append(target)
        except requests.RequestException:
            continue
        time.sleep(0.08)
    return pages

def terms(s):
    return [w.lower() for w in re.findall(r"[A-Za-zÄÖÜäöüß0-9_-]{3,}", s)]

def retrieve(question, pages, limit=5):
    qterms = set(terms(question))
    scored = []
    for page in pages:
        body_terms = terms(page["title"] + " " + page["text"])
        if not body_terms:
            continue
        counts = {}
        for w in body_terms:
            counts[w] = counts.get(w, 0) + 1
        score = sum(min(counts.get(w, 0), 6) for w in qterms)
        # Small title boost
        title_terms = set(terms(page["title"]))
        score += 3 * len(qterms.intersection(title_terms))
        if score:
            scored.append((score, page))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [p for _, p in scored[:limit]]

def generate_answer(question, sources):
    # Local development reads .env; Streamlit Community Cloud can use st.secrets.
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    model = os.getenv("OPENAI_MODEL", "").strip()
    try:
        if not api_key:
            api_key = str(st.secrets.get("OPENAI_API_KEY", "")).strip()
        if not model:
            model = str(st.secrets.get("OPENAI_MODEL", "gpt-4.1-mini")).strip()
    except Exception:
        pass
    if not api_key:
        return None, "Falta configurar OPENAI_API_KEY nas configurações do aplicativo. Consulte o README."
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        source_text = "\n\n".join(
            f"FONTE {i+1}\nTÍTULO: {p['title']}\nURL: {p['url']}\nCONTEÚDO: {p['text'][:6500]}"
            for i, p in enumerate(sources)
        )
        instructions = (
            "Você é a KAMAT Assistente IA, uma assistente de orientação para operadores industriais. "
            "Responda em português claro e conciso. Use SOMENTE os trechos fornecidos, que foram obtidos "
            "de páginas do domínio kamat.de. Não use conhecimento externo nem complete lacunas. "
            "Se os trechos não responderem à pergunta, diga exatamente que não encontrou informação suficiente "
            "nas páginas KAMAT consultadas e peça o modelo da máquina ou recomende consultar o procedimento "
            "oficial/supervisor. Ao final, liste as fontes realmente usadas com título e URL. "
            "Nunca dê instruções para desativar proteções, contornar intertravamentos ou realizar intervenção "
            "perigosa. Não controle a máquina. Para dúvidas sobre pressão alta, manutenção, falhas ou segurança, "
            "seja conservador e remeta ao manual específico e aos procedimentos locais."
        )
        response = client.responses.create(
            model=model or "gpt-4.1-mini",
            instructions=instructions,
            input=f"PERGUNTA DO OPERADOR:\n{question}\n\nTRECHOS AUTORIZADOS:\n{source_text}",
        )
        return response.output_text, None
    except Exception as e:
        return None, f"Não foi possível gerar a resposta com a API. Detalhe: {e}"

st.title("🏭 KAMAT Assistente IA")
st.caption("Protótipo para Windows 11 • Consulta apenas páginas de kamat.de • Não controla a máquina")

with st.sidebar:
    st.subheader("Configuração")
    st.write("Fonte permitida: **kamat.de**")
    st.write("A assistente só utiliza páginas que conseguir carregar desse domínio.")
    if st.button("Atualizar índice do site"):
        crawl_kamat.clear()
        st.rerun()
    st.caption("O site pode bloquear algumas páginas ou exigir acesso específico. Documentos não encontrados não serão presumidos.")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message.get("sources"):
            with st.expander("Fontes consultadas"):
                for src in message["sources"]:
                    st.markdown(f"- [{src['title']}]({src['url']})")

question = st.chat_input("Pergunte sobre a documentação KAMAT…")
if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)
    with st.chat_message("assistant"):
        with st.spinner("Consultando páginas autorizadas da KAMAT…"):
            pages = crawl_kamat()
            if not pages:
                answer = "Não consegui carregar páginas do site KAMAT. Verifique a conexão e tente novamente. Nenhuma outra fonte foi consultada."
                sources = []
            else:
                sources = retrieve(question, pages)
                if not sources:
                    answer = "Não encontrei informação suficiente nas páginas KAMAT que consegui consultar para responder com segurança. Tente informar o modelo exato da bomba ou consulte o manual específico e o responsável técnico."
                    sources = []
                else:
                    answer, error = generate_answer(question, sources)
                    if error:
                        answer = error + "\n\nNenhuma resposta técnica foi gerada."
                        sources = []
                    else:
                        answer += "\n\n**Fontes consultadas:**\n" + "\n".join(
                            f"- [{p['title']}]({p['url']})" for p in sources
                        )
            st.markdown(answer)
            st.session_state.messages.append({
                "role": "assistant",
                "content": answer,
                "sources": sources
            })

with st.expander("Aviso de segurança"):
    st.warning(
        "Este protótipo é apenas informativo. Não se conecta ao PLC, não lê sensores e não comanda a máquina. "
        "Não use a resposta da IA como substituto do manual específico, dos procedimentos da fábrica, do treinamento "
        "ou do responsável técnico. Antes de qualquer intervenção, siga os procedimentos de segurança e bloqueio "
        "aplicáveis."
    )
